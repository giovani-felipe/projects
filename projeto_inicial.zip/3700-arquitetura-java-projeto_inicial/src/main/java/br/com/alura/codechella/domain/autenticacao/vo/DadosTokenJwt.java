package br.com.alura.codechella.domain.autenticacao.vo;

public record DadosTokenJwt(String type, String token) {}
