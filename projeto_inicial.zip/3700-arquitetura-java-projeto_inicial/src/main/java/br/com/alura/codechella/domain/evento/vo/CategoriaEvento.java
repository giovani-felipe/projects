package br.com.alura.codechella.domain.evento.vo;

public enum CategoriaEvento {

    FESTIVAL,
    MUSICA,
    TEATRO,
    OUTROS

}
