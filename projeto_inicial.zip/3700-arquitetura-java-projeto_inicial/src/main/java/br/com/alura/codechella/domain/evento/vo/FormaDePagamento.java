package br.com.alura.codechella.domain.evento.vo;

public enum FormaDePagamento {

    DINHEIRO,
    PIX,
    DEBITO,
    CREDITO;

}
