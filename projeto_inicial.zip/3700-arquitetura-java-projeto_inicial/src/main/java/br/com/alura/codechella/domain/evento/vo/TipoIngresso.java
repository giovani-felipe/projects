package br.com.alura.codechella.domain.evento.vo;

public enum TipoIngresso {

    INTEIRA,
    MEIA_ESTUDANTE,
    MEIA_BAIXA_RENDA,
    MEIA_IDOSO;

}
